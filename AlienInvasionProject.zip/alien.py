import pygame as pg
from vector import Vector
from point import Point
from laser import Laser 
from pygame.sprite import Sprite
from timer import Timer
from random import randint

class Alien(Sprite):
    n = 0
    alien_images0 = [pg.image.load(f"images/alien0{n}.png") for n in range(2)]
    alien_images1 = [pg.image.load(f"images/alien1{n}.png") for n in range(2)]
    alien_images2 = [pg.image.load(f"images/alien2{n}.png") for n in range(2)]
    alien_images = [alien_images0, alien_images1, alien_images2]

    points100 = [pg.image.load(f"images/100p{n}.png") for n in range(2)]
    points200 = [pg.image.load(f"images/200p{n}.png") for n in range(2)]
    points300 = [pg.image.load(f"images/300p{n}.png") for n in range(2)]

    def __init__(self, ai_game, v): 
        super().__init__()
        self.ai_game = ai_game
        self.screen = ai_game.screen
        self.settings = ai_game.settings
        self.v = v
        type = randint(0, 2)

        self.ptype = type

        alien_explosion_images = [pg.image.load(f"images/a_explosion{n}.png") for n in range(4)]

        if self.ptype == 0:
            alien_explosion_images += Alien.points100
        elif self.ptype == 1:
            alien_explosion_images += Alien.points200
        elif self.ptype == 2:
            alien_explosion_images += Alien.points300

        self.timer = Timer(images=self.alien_images[type], delta=(type+1)*600, start_index=type % 2)

        self.explosion = Timer(images=alien_explosion_images, start_index=0, loop_continuously=False, delta=100)
        self.image = self.timer.current_image()
        self.rect = self.image.get_rect()
        self.rect.x = self.rect.width
        self.rect.y = self.rect.height
        
        self.x = float(self.rect.x)
        self.y = float(self.rect.y)

        self.dead = False

    def check_edges(self):
        sr = self.screen.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        r = self.rect 
        return self.x + self.rect.width >= sr.right or self.x <= 0
    
    def hit(self):
        self.dead = True
        self.timer = self.explosion
        print(self.timer)

    def update(self):
        if not self.dead:
            self.x += self.v.x
            self.y += self.v.y
        self.image = self.timer.current_image()
        
        if self.timer.finished() and self.dead:
            self.kill()
            print("self.kill() executed")
        self.draw()


    def draw(self): 
        self.rect.x = self.x
        self.rect.y = self.y
        self.screen.blit(self.image, self.rect)


def main():
    print('\n run from alien_invasions.py\n')

if __name__ == "__main__":
    main()




