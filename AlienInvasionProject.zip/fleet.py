import pygame as pg
from vector import Vector
from point import Point
from laser import Laser 

from alien import Alien
from pygame.sprite import Sprite
import time
import random
import settings
from sound import Sound

class Fleet(Sprite):
    def __init__(self, ai_game): 
        self.ai_game = ai_game
        self.screen = ai_game.screen
        self.ship = ai_game.ship
        self.aliens = pg.sprite.Group()
        self.settings = ai_game.settings
        self.laser = pg.Rect(0, 0, self.settings.laser_width,
                                self.settings.laser_height)
        self.fleet_lasers = pg.sprite.Group()
        self.sound = Sound()


        self.settings = ai_game.settings
        self.stats = ai_game.stats
        self.sb = ai_game.sb
        self.v = Vector(self.settings.alien_speed, 0)
        self.spacing = 1.4
        self.create_fleet()

        self.explosion_list = []
        self.points_list = []

    def reset_fleet(self):
        self.aliens.empty()
        self.create_fleet()

    def create_fleet(self):
        alien = Alien(ai_game=self.ai_game, v=self.v)
        alien_height = alien.rect.height
        current_y = alien_height
        while current_y < (self.settings.scr_height - self.spacing * 6 * alien_height):
            self.create_row(current_y)
            current_y += self.spacing * alien_height
        
    def create_row(self, y):
        alien = Alien(ai_game=self.ai_game, v=self.v)
        alien_width = alien.rect.width
        current_x = alien_width 
        while current_x < (self.settings.scr_width - self.spacing * alien_width):
             new_alien = Alien(self, v=self.v)
             new_alien.rect.y = y
             new_alien.y = y
             new_alien.x = current_x
             new_alien.rect.x = current_x
             self.aliens.add(new_alien)
             current_x += self.spacing * alien_width

    def check_edges(self):
        for alien in self.aliens:
            if alien.check_edges(): 
                return True 
        return False
    
    def check_bottom(self):
        for alien in self.aliens:
            if alien.rect.bottom >= self.settings.scr_height:
                self.ship.ship_hit()
                return True
        return False
    
    

    def update(self): 
        collisions = pg.sprite.groupcollide(self.ship.lasers, self.aliens, True, False)
        if collisions:
            for aliens in collisions.values():
                self.v *= 1.06
                for alien in aliens:
                    if alien.ptype == 0:
                        points = 100
                    elif alien.ptype == 1:
                        points = 200
                    elif alien.ptype == 2:
                        points = 300
                    self.stats.score += points
                    self.sound.play_alien_explosion()
                    alien.hit()

        num1 = random.randint(1, 100)
        num2 = random.randint(1, 100)

        for laser in self.fleet_lasers.copy():
            if laser.rect.top >= 900:
                self.fleet_lasers.remove(laser)
        for laser in self.fleet_lasers:
            self.alien_lasers_update(laser) 
        
        if num1 == num2:
            self.shoot()
            
        if not self.aliens:
            self.ship.lasers.empty()
            self.v = Vector(self.settings.alien_speed, 0)
            self.create_fleet()
                    # Increase level.
            self.stats.level += 1
            self.settings.increase_speed()

            self.sb.prep_level()
            return
        
        if pg.sprite.spritecollideany(self.ship, self.aliens):
            self.v = Vector(self.settings.alien_speed, 0)
            self.ship.ship_hit()
            
            return
        
        laser_collisions = pg.sprite.spritecollideany(self.ship, self.fleet_lasers)
        if laser_collisions:
            self.v = Vector(self.settings.alien_speed, 0)
            self.ship.ship_hit()
            self.fleet_lasers.empty()
        
        if self.check_bottom():
            return 
        
        if self.check_edges():
            self.v.x *= -1 
            for alien in self.aliens:
                alien.v.x = self.v.x
                alien.y += self.settings.fleet_drop_speed
    
        self.sb.prep_score()
        self.sb.check_high_score()

        for alien in self.aliens:
            alien.update()
        
    def shoot (self):
        laser = Laser(self.ai_game) 
        rand_alien = random.choice(list(self.aliens.sprites()))
        laser.rect.centerx = rand_alien.rect.centerx
        laser.rect.top = rand_alien.rect.top
        self.fleet_lasers.add(laser)
        pg.draw.rect(self.screen, (0, 0, 0), laser)


    def alien_lasers_update(self, laser):
            laser.rect.y += self.settings.laser_speed
            pg.draw.rect(self.screen, (0, 0, 0), laser)

    def draw(self): pass
        # for alien in self.aliens:
        #     alien.draw()

def main():
    print('\n run from alien_invasions.py\n')

if __name__ == "__main__":
    main()
