import pygame as pg 
import time


class Sound:
    def __init__(self): 
        self.pickup = pg.mixer.Sound('sounds/pickup.wav')
        self.gameover = pg.mixer.Sound('sounds/game_over.wav')
        self.alien_explosion = pg.mixer.Sound('sounds/alien_explode.wav') 
        self.laser_fire = pg.mixer.Sound('sounds/fire_bullet.wav') 
        self.ufo_sound = pg.mixer.Sound('sounds/ufo_appear.wav')
        self.ship_explosion = pg.mixer.Sound('sounds/ship_explode.wav') ###TEMP SOUND 
        pg.mixer.music.load('sounds/ride_of_the_valkyries.mp3')
        pg.mixer.music.set_volume(0.2)
                                             
    def play_background(self): 
        pg.mixer.music.play(-1, 0.0)
        self.music_playing = True
        
    def play_pickup(self): 
        if self.music_playing: self.pickup.play()
        
    def play_gameover(self):
        if self.music_playing: 
            self.stop_background()
            self.gameover.play()
            time.sleep(3.0)       # sleep until game over sound has finished

    def play_alien_explosion(self):
        self.alien_explosion.play()

    def play_laser_fire(self):
        self.laser_fire.play()

    def play_ufo_sound(self):
        self.ufo_sound.play()

    def play_ship_explosion(self):
        self.ship_explosion.play()
        
    def toggle_background(self):
        if self.music_playing: 
            self.stop_background()
        else:
            self.play_background()
        self.music_playing = not self.music_playing
        
    def stop_background(self): 
        pg.mixer.music.stop()
        self.music_playing = False 