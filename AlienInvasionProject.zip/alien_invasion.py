import sys
import pygame as pg
import random 
from colors import OFF_WHITE, DARK_GREY
from settings import Settings
from ship import Ship
from vector import Vector
from fleet import Fleet
from game_stats import GameStats
from button import Button
from scoreboard import Scoreboard
from event import Event
from barrier import Barriers
from sound import Sound
from bonus_alien import BonusAlien 
class AlienInvasion:
    def __init__(self):
        pg.init()
        self.clock = pg.time.Clock()
        self.settings = Settings()
        self.screen = pg.display.set_mode(self.settings.w_h)
        self.stats = GameStats(self)
        self.sb = Scoreboard(self)
        self.sound = Sound()

        self.ship = Ship(ai_game=self)
        self.fleet = Fleet(ai_game=self)
        self.ship.set_fleet(self.fleet)
        self.ship.set_sb(self.sb)
        self.barriers = Barriers(ai_game=self)

        pg.display.set_caption("Alien Invasion")
        self.bg_color = self.settings.bg_color

        # Start Alien Invasion in an inactive state.
        self.game_active = False
        self.first = True

        self.play_button = Button(self, "Play")
        self.event = Event(self)
        self.game_overs = 0

        try:
            with open('highscore.txt', 'r') as f:
                self.highscore = f.read().strip()
        except FileNotFoundError:
            self.highscore = 0

        self.bonus_alien = None  # Attribute to hold the bonus alien
        self.bonus_alien_spawned = False  # This is the new attribute that tracks if the bonus alien has been spawned
        self.last_spawn_time = pg.time.get_ticks()  # Time when the last alien was spawned
        self.spawn_delay = 6000  # Time in ms before the bonus alien should spawn
        self.all_sprites = pg.sprite.Group()  # Group to hold all sprites

    def game_over(self):
        self.highscore = int(self.highscore)
        if self.sb.stats.high_score > self.highscore:
            with open('highscore.txt', 'w') as f:
                f.write(str(self.sb.stats.high_score))
                self.highscore = self.sb.stats.high_score
        self.game_overs += 1
        self.sound.play_gameover()
        self.game_active = False
        self.restart_game()
        self.stats.reset_stats()

    def reset_game(self):
        self.stats.reset_stats()
        self.sb.prep_score_level_ships()
        self.game_active = True
        self.sound.play_background()
        self.ship.reset_ship()
        self.fleet.reset_fleet()
        pg.mouse.set_visible(True)

    def restart_game(self):
        self.game_active = False
        self.play_button.reset_message("Play again?")

    def draw_start_menu(self):
        self.screen.fill(self.bg_color)
        alien1 = pg.image.load(f"images/alien00.png")
        alien2 = pg.image.load(f"images/alien10.png")
        alien3 = pg.image.load(f"images/alien20.png")
        ufo = pg.image.load(f"images/ufo.png")

        font = pg.font.SysFont(None, 64)
        title = pg.font.SysFont(None, 200)

        text1 = font.render("= 100", True, (0, 0, 0))
        text2 = font.render("= 200", True, (0, 0, 0))
        text3 = font.render("= 300", True, (0, 0, 0))
        text4 = font.render("= ???", True, (0, 0, 0))
        hs_text = font.render(f"High Score = {self.highscore}", True, (0, 0, 0))

        title1 = title.render("ALIEN", True, (0, 0, 0))
        title2 = title.render("INVASION", True, (0, 0, 0))
        self.screen.blit(title1, [400, 20])
        self.screen.blit(title2, [250, 150])

        y = 550
        x = (1200 // 2) - 100
        textx = 575

        self.screen.blit(hs_text, [425, 300])
        self.screen.blit(alien1, [x, y])
        self.screen.blit(text1, (textx, y))
        self.screen.blit(alien2, [x, (y + 75)])
        self.screen.blit(text2, [textx, (y + 80)])
        self.screen.blit(alien3, [x, (y + 150)])
        self.screen.blit(text3, [textx, (y + 155)])
        self.screen.blit(ufo, [x, (y - 75)])
        self.screen.blit(text4, [textx, (y - 70)])

    def spawn_bonus_alien(self):
        """Spawn the bonus alien only if it hasn't been spawned already."""
        if not self.bonus_alien_spawned:
            current_time = pg.time.get_ticks()
            if current_time - self.last_spawn_time >= self.spawn_delay:
                self.bonus_alien = BonusAlien(self)
                self.all_sprites.add(self.bonus_alien)  # Add the BonusAlien to the sprite group
                self.bonus_alien_spawned = True 
                self.last_spawn_time = current_time
                print("Bonus Alien spawned!")

    def run_game(self):
        self.finished = False
        while not self.finished:
            self.finished = self.event.check_events()
            if self.first or self.game_active:
                self.first = False
                self.screen.fill(self.bg_color)
                self.ship.update()
                self.fleet.update()
                self.sb.show_score()
                self.barriers.update()

                # Handle the Bonus Alien (UFO)
                if not self.bonus_alien_spawned:  # Only attempt to spawn the UFO once
                    self.spawn_bonus_alien()

                # Update and draw all sprites
                self.all_sprites.update()
                for sprite in self.all_sprites:
                    self.screen.blit(sprite.image, sprite.rect)

                # Check for collision with lasers (assuming BonusAlien has check_collision method)
                if self.bonus_alien:
                    self.bonus_alien.check_collision()  # Check for collision with lasers

                # Remove the BonusAlien if it goes off the screen
                if self.bonus_alien and (self.bonus_alien.rect.left > self.settings.scr_width or self.bonus_alien.rect.right < 0):
                    self.bonus_alien.kill()  # Remove the UFO from all sprite groups
                    self.bonus_alien = None  # Reset UFO
                    self.bonus_alien_spawned = False  # Ensure it does not respawn

            if not self.game_active:
                self.draw_start_menu()
                self.play_button.draw_button()

            pg.display.flip()
            self.clock.tick(60)

        sys.exit()

if __name__ == '__main__':
    ai = AlienInvasion()
    ai.run_game()
